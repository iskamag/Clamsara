;;;; Executable v14 SemiSpace lifecycle integration.
(defpackage #:clamsara.runtime.test
  (:use #:cl #:clamsara)
  (:export #:run-v14-runtime-tests))
(in-package #:clamsara.runtime.test)

(defun %check (value format-control &rest arguments)
  (unless value (apply #'error format-control arguments))
  value)

(defun %stale-reference-p (model reference)
  ;; VALID-REFERENCE-P classifies encodings; it deliberately does not certify
  ;; that the encoded representation is still allocated.
  (handler-case
      (progn (normalize-reference model reference) nil)
    (error () t)))

(defun %check-cycle-counts (record expected)
  (dolist (entry expected)
    (multiple-value-bind (count known-p)
        (cycle-result-count record (car entry))
      (%check (and known-p (= count (cdr entry)))
              "Counter ~S expected ~D, got ~S/~S"
              (car entry) (cdr entry) count known-p)))
  (values))

(defun %runtime-rejection-reason (thunk)
  (handler-case (progn (funcall thunk) nil)
    (clamsara::runtime-rejection (condition)
      (clamsara::runtime-rejection-reason condition))))

(defun run-v14-runtime-tests ()
  (let* ((q 16) (extent 1024) (base 4096)
         (roots (clamsara::make-simulator-root-client :provider-capacity 8))
         (application-roots (clamsara::make-simulator-root-provider 1))
         (application-token
           (register-root-provider roots :application 1 application-roots))
         (coordinator
           (clamsara::make-simulator-coordinator
            roots :stop-capacity 16 :await-bound 16))
         (address-space
           (clamsara::make-simulator-address-space
            :base base :byte-extent (* 2 extent) :alignment q :page-size 256
            :coordinator coordinator))
         (model (clamsara::make-host-object-model
                 :capacity 256 :slot-capacity 8 :handle-capacity 64
                 :max-object-bytes 128))
         (kind (make-object-kind-description
                model :node :size-rule 32 :alignment-rule q
                :strong-layout '(:left :right)))
         (atomics (clamsara::make-host-atomics))
         (diagnostics (clamsara::make-simulator-diagnostics))
         (clients (clamsara::make-simulator-clients
                   :model model :roots roots :coordinator coordinator
                   :address-space address-space :atomics atomics
                   :diagnostics diagnostics))
         (domain-0 (clamsara::make-metadata-domain
                    :base base :limit (+ base extent) :granularity q))
         (domain-1 (clamsara::make-metadata-domain
                    :base (+ base extent) :limit (+ base (* 2 extent))
                    :granularity q))
         (from (clamsara::make-semispace-space
                :name :from
                :object-start-map
                (clamsara::make-object-start-marks :domain domain-0)
                :forwarding
                (clamsara::make-side-forwarding :domain domain-0)
                :extent extent :packing-quantum q :role :allocation))
         (to (clamsara::make-semispace-space
              :name :to
              :object-start-map
              (clamsara::make-object-start-marks :domain domain-1)
              :forwarding
              (clamsara::make-side-forwarding :domain domain-1)
              :extent extent :packing-quantum q :role :reserve))
         (registry (clamsara::make-sequential-finalizer-registry
                    :capacity 8 :root-client roots))
         (plan (clamsara::make-semispace-plan
                :from-space from :to-space to :root-client roots
                :coordinator coordinator :diagnostics diagnostics
                :registry registry :trace-capacity 64
                :conditional-capacity 64 :finalizer-capacity 8
                :packing-quantum q))
         (configuration (construct-plan plan clients))
         (context (bind-mutator configuration :runtime-test :default))
         (bound (configuration-object-model configuration)))
    (labels ((allocate-node ()
               (multiple-value-bind (reference status reason)
                   (allocate-object context :node 32 q kind)
                 (%check (eq status :allocated)
                         "Allocation failed: ~S" reason)
                 reference))
             (store-slot (object wanted value)
               (let ((index 0) (stored nil))
                 (map-reference-locations
                  bound object
                  (lambda (identity location)
                    (declare (ignore identity))
                    (when (= index wanted)
                      (multiple-value-bind (effective status)
                          (barrier-store (configuration-barrier configuration)
                                         context location value)
                        (%check (eq status :stored)
                                "Barrier store returned ~S" status)
                        (setf stored effective)))
                    (incf index)))
                 stored))
             (read-slot (object wanted)
               (let ((index 0) (result nil) (found nil))
                 (map-reference-locations
                  bound object
                  (lambda (identity location)
                    (declare (ignore identity))
                    (when (= index wanted)
                      (multiple-value-bind (value status)
                          (barrier-read (configuration-barrier configuration)
                                        context location)
                        (%check (eq status :complete)
                                "Barrier read returned ~S" status)
                        (setf result value found t)))
                    (incf index)))
                 (%check found "Missing strong slot ~D" wanted)
                 result)))
      (let ((a (allocate-node)) (b (allocate-node)) (dead (allocate-node)))
        (store-slot a 0 b)
        (store-slot b 0 a)
        (multiple-value-bind (effective status)
            (root-provider-store
             roots context application-token
             (clamsara::simulator-root-location application-roots 0) a)
          (declare (ignore effective))
          (%check (eq status :stored) "Root store returned ~S" status))
        ;; No heap-generational collector is implemented.  Reject both its
        ;; public scope and algorithm before result, plan, stop or roots change.
        (dolist (case '((:minor :unsupported-scope nil)
                        (:all :unsupported-algorithm :generational)))
          (destructuring-bind (scope expected algorithm) case
            (let ((rejected-record (make-cycle-result-record plan)))
              (%check
               (eq expected
                   (%runtime-rejection-reason
                    (lambda ()
                      (if algorithm
                          (collect configuration scope :explicit rejected-record
                                   :algorithm algorithm)
                          (collect configuration scope :explicit
                                   rejected-record)))))
               "Unsupported generational entry ~S/~S was admitted"
               scope algorithm)
              (%check (and (eq :uninitialized
                               (cycle-result-status rejected-record))
                           (eq :open (clamsara::%plan-state plan))
                           (eq :idle
                               (clamsara::simulator-stop-state coordinator))
                           (reference-encoding-equal-p
                            bound a
                            (root-provider-load
                             roots application-token
                             (clamsara::simulator-root-location
                              application-roots 0))))
                      "Unsupported generational entry caused effects"))))
        (let ((old-a-address (reference-address bound a))
              (record (make-cycle-result-record plan)))
          (collect configuration :all :explicit record)
          (%check (eq :complete (cycle-result-status record))
                  "Cycle status/reason: ~S/~S"
                  (cycle-result-status record) (cycle-result-reason record))
          (%check-cycle-counts
           record '((:objects-discovered . 2) (:objects-moved . 2)
                    (:bytes-moved . 64) (:objects-dead . 1)
                    (:weak-corrections . 0) (:finalizers-enqueued . 0)))
          (%check (%stale-reference-p bound dead)
                  "Dead source representation was not retired")
          (let* ((first-a
                   (root-provider-load
                    roots application-token
                    (clamsara::simulator-root-location
                     application-roots 0)))
                 (first-b (read-slot first-a 0)))
            (%check (/= old-a-address (reference-address bound first-a))
                    "Root was not corrected to the other semispace")
            (%check (reference-equal bound (read-slot first-b 0) first-a)
                    "First cycle did not preserve sharing")
            (let ((second-record (make-cycle-result-record plan)))
              (collect configuration :all :explicit second-record)
              (%check (eq :complete (cycle-result-status second-record))
                      "Repeat cycle status/reason: ~S/~S"
                      (cycle-result-status second-record)
                      (cycle-result-reason second-record))
              (%check-cycle-counts
               second-record
               '((:objects-discovered . 2) (:objects-moved . 2)
                 (:bytes-moved . 64) (:objects-dead . 0)
                 (:weak-corrections . 0) (:finalizers-enqueued . 0)))
              (%check (%stale-reference-p bound first-a)
                      "First destination representation was not retired")
              (let* ((second-a
                       (root-provider-load
                        roots application-token
                        (clamsara::simulator-root-location
                         application-roots 0)))
                     (second-b (read-slot second-a 0)))
                (%check (= old-a-address (reference-address bound second-a))
                        "Repeat cycle did not alternate back to the first space")
                (%check (reference-equal bound (read-slot second-b 0) second-a)
                        "Repeat cycle did not preserve sharing")))))))
    (%check (eq :unbound (unbind-mutator configuration context))
            "Mutator did not unbind")
    (format t "~&V14-SEMISPACE-LIFECYCLE-OK~%")
    t))
