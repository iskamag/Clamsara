;;;; Hosted byte-address arena and authoritative ownership layout.
(in-package #:clamsara)

(defstruct (%simulator-arena-offer (:constructor %make-simulator-arena-offer))
  name base extent alignment page-size accesses address-width exclusions)
(defstruct (%simulator-layout-range (:constructor %make-simulator-layout-range))
  (space nil :read-only nil) (map nil :read-only nil)
  (base 0 :read-only t) (limit 0 :read-only t) (generation 0) pending)
(defstruct (%simulator-layout-release (:constructor %make-simulator-layout-release))
  client layout (released-p nil))
(defstruct (%simulator-ownership-capability (:constructor %make-simulator-ownership-capability))
  layout route owner map stop-token (generation 0) (state :unused))
(defclass simulator-address-space ()
  ((offer :initarg :offer :reader %simulator-arena-offer)
   (active :initform nil :accessor %simulator-active-layout)
   (coordinator :initarg :coordinator :reader %simulator-address-coordinator)
   (ownership-capacity :initarg :ownership-capacity :reader %simulator-ownership-capacity)))
(defclass simulator-installed-layout ()
  ((client :initarg :client :reader %simulator-layout-client)
   (solution :initarg :solution :reader %simulator-layout-solution)
   (ranges :initarg :ranges :reader simulator-layout-ranges)
   (ownership-reserve :initarg :ownership-reserve :reader %simulator-ownership-reserve)
   (next-ownership :initform 0 :accessor %simulator-next-ownership)
   (active-p :initform t :accessor %simulator-layout-active-p)))

(defun make-simulator-address-space (&key (base 4096) (byte-extent (* 16 1024 1024))
                                         (alignment 16) (page-size 4096)
                                         (address-width 48) exclusions coordinator
                                         (ownership-capacity 64))
  (unless (and (typep base '(integer 0 #.most-positive-fixnum))
               (typep byte-extent '(integer 1 #.most-positive-fixnum))
               (typep alignment '(integer 1 #.most-positive-fixnum))
               (zerop (logand alignment (1- alignment)))
               (zerop (mod base alignment))
               (typep page-size '(integer 1 #.most-positive-fixnum))
               (typep address-width '(integer 1 60))
               (< (+ base byte-extent) (ash 1 address-width))
               (typep ownership-capacity '(integer 0 #.most-positive-fixnum)))
    (error 'construction-rejected :reason :invalid-simulator-arena))
  (make-instance 'simulator-address-space
   :offer (%make-simulator-arena-offer
           :name :simulator-arena :base base :extent byte-extent
           :alignment alignment :page-size page-size
           :accesses '(:read :write :atomic) :address-width address-width
           :exclusions (copy-tree exclusions))
   :coordinator coordinator :ownership-capacity ownership-capacity))
(defmethod managed-arena-offer ((client simulator-address-space))
  (%simulator-arena-offer client))
(defmethod describe-managed-arena-offer
    ((client simulator-address-space) (offer %simulator-arena-offer))
  (unless (eq offer (%simulator-arena-offer client))
    (error 'construction-rejected :reason :foreign-arena-offer))
  (values (%simulator-arena-offer-name offer) (%simulator-arena-offer-base offer)
          (%simulator-arena-offer-extent offer) (%simulator-arena-offer-alignment offer)
          (%simulator-arena-offer-page-size offer) (%simulator-arena-offer-accesses offer)
          (%simulator-arena-offer-address-width offer) (%simulator-arena-offer-exclusions offer)))
(defmethod %address-space-policy-supported-p
    ((client simulator-address-space) kind identity)
  (declare (ignore client))
  (case kind
    (:lifetime (eq identity :configuration))
    (:mobility (eq identity :fixed))
    (:reclaimability (member identity '(:collector :retained)))
    (otherwise nil)))
(defmethod %evaluate-construction-constraint
    ((client simulator-address-space) kind tagged-values parameters)
  (declare (ignore client kind tagged-values parameters))
  (values nil nil))

(defun %simulator-solution-space (solution)
  (let ((map (%placement-solution-object-start-map solution)))
    (and map (%placement-description-owner (%placement-solution-description solution)))))
(defmethod validate-managed-layout
    ((client simulator-address-space) (layout %reference-layout))
  (when (%simulator-active-layout client)
    (error 'construction-rejected :reason :arena-already-installed))
  (unless (eq (%arena-description-actual (%layout-arena layout))
              (%simulator-arena-offer client))
    (error 'construction-rejected :reason :foreign-layout-arena))
  ;; Solver owns full constraint validation; host independently verifies every
  ;; installed object route is within its arena and never ambiguously owned.
  (let* ((solutions (%layout-ordered-solutions layout))
         (offer (%simulator-arena-offer client))
         (base (%simulator-arena-offer-base offer))
         (limit (+ base (%simulator-arena-offer-extent offer)))
         ;; Construction-only scratch.  Never reorder the authoritative
         ;; solution vector or retain a second ownership index.
         (routes (make-array (length solutions) :fill-pointer 0)))
    (dotimes (i (length solutions))
      (let ((solution (aref solutions i)))
        (unless (<= base (%placement-solution-base solution)
                    (%placement-solution-exclusive-limit solution) limit)
          (error 'construction-rejected :reason :layout-outside-arena))
        (when (and (%simulator-solution-space solution)
                   (< (%placement-solution-base solution)
                      (%placement-solution-exclusive-limit solution)))
          (vector-push solution routes))))
    ;; Adjacent intervals in address order suffice after empty routes are
    ;; excluded.  Extract each route once rather than scan every predecessor.
    (sort routes #'< :key #'%placement-solution-base)
    (let ((previous-limit nil))
      (dotimes (i (length routes))
        (let ((route (aref routes i)))
          (when (and previous-limit
                     (< (%placement-solution-base route) previous-limit))
            (error 'construction-rejected :reason :ambiguous-space-ownership))
          (setf previous-limit (%placement-solution-exclusive-limit route))))))
  (values))
(defmethod install-managed-layout
    ((client simulator-address-space) (solution %reference-layout))
  (validate-managed-layout client solution)
  (let ((ranges nil))
    (map nil (lambda (placement)
               (let ((space (%simulator-solution-space placement)))
                 (when space
                   (push (%make-simulator-layout-range
                          :space space :map (%placement-solution-object-start-map placement)
                          :base (%placement-solution-base placement)
                          :limit (%placement-solution-exclusive-limit placement)) ranges))))
         (%layout-ordered-solutions solution))
    (let* ((reserve (make-array (%simulator-ownership-capacity client)))
           (layout (make-instance 'simulator-installed-layout :client client :solution solution
                     :ranges (coerce (nreverse ranges) 'simple-vector) :ownership-reserve reserve))
           (release (%make-simulator-layout-release :client client :layout layout)))
      (dotimes (i (length reserve))
        (setf (aref reserve i) (%make-simulator-ownership-capability :layout layout)))
      ;; Last, non-failing effect. Failure before this point installs nothing.
      (setf (%simulator-active-layout client) layout)
      (values layout release))))
(defmethod release-managed-layout
    ((client simulator-address-space) (release %simulator-layout-release))
  (unless (eq client (%simulator-layout-release-client release))
    (error 'construction-rejected :reason :foreign-layout-release))
  (unless (%simulator-layout-release-released-p release)
    (let ((layout (%simulator-layout-release-layout release)))
      (when (eq layout (%simulator-active-layout client))
        (setf (%simulator-active-layout client) nil))
      (setf (%simulator-layout-active-p layout) nil
            (%simulator-layout-release-released-p release) t)))
  (values))
(defun %simulator-layout-owner-at-address (layout address)
  (when (%simulator-layout-active-p layout)
    (let ((ranges (simulator-layout-ranges layout)))
      (dotimes (i (length ranges))
        (let ((range (aref ranges i)))
          (when (<= (%simulator-layout-range-base range) address
                    (1- (%simulator-layout-range-limit range)))
            (return-from %simulator-layout-owner-at-address
              (%simulator-layout-range-space range))))))))
(defmethod space-of-reference ((layout simulator-installed-layout) start-reference)
  (%simulator-layout-owner-at-address layout (simulator-reference-address start-reference)))

(defmethod prepare-space-ownership-update
    ((layout simulator-installed-layout) model range owner)
  (flet ((reject (reason) (values nil :rejected reason)))
    (unless (and (%simulator-layout-active-p layout)
                 (eq layout (%simulator-model-layout model)))
      (return-from prepare-space-ownership-update (reject :foreign-bound-model)))
    (let ((coordinator (%simulator-address-coordinator (%simulator-layout-client layout))))
      (unless (and coordinator (eq :covered (simulator-stop-state coordinator)))
        (return-from prepare-space-ownership-update (reject :unprotected-ownership-update))))
    (unless (and (consp range) (integerp (car range)) (integerp (cdr range))
                 (< (car range) (cdr range)))
      (return-from prepare-space-ownership-update (reject :invalid-ownership-range)))
    (let ((target nil) (map nil) (routes (simulator-layout-ranges layout)))
      (dotimes (i (length routes))
        (let ((r (aref routes i)))
          (when (eq owner (%simulator-layout-range-space r))
            (setf map (%simulator-layout-range-map r)))
          (when (and (= (car range) (%simulator-layout-range-base r))
                     (= (cdr range) (%simulator-layout-range-limit r)))
            (setf target r))))
      (unless (and target map)
        (return-from prepare-space-ownership-update (reject :foreign-space-or-range)))
      (multiple-value-bind (base limit granularity) (metadata-bounds map)
        (unless (and (<= base (car range) (cdr range) limit)
                     (zerop (mod (- (car range) base) granularity))
                     (zerop (mod (- (cdr range) base) granularity)))
          (return-from prepare-space-ownership-update (reject :uncovered-object-start-map))))
      ;; Bound representations index this physical range at its admitted
      ;; granularity. Ownership/generation may change; cell geometry may not.
      (multiple-value-bind (old-base old-limit old-granularity)
          (metadata-bounds (%simulator-layout-range-map target))
        (declare (ignore old-base old-limit))
        (multiple-value-bind (new-base new-limit new-granularity)
            (metadata-bounds map)
          (declare (ignore new-base new-limit))
          (unless (= old-granularity new-granularity)
            (return-from prepare-space-ownership-update
              (reject :incompatible-object-start-granularity)))))
      (when (%simulator-layout-range-pending target)
        (return-from prepare-space-ownership-update (reject :ownership-update-pending)))
      (when (= most-positive-fixnum (%simulator-layout-range-generation target))
        (return-from prepare-space-ownership-update (reject :ownership-generation-exhausted)))
      (let ((index (%simulator-next-ownership layout))
            (reserve (%simulator-ownership-reserve layout)))
        (when (= index (length reserve))
          (return-from prepare-space-ownership-update (reject :ownership-capacity-exhausted)))
        (let ((capability (aref reserve index)))
          (setf (%simulator-ownership-capability-route capability) target
                (%simulator-ownership-capability-owner capability) owner
                (%simulator-ownership-capability-map capability) map
                (%simulator-ownership-capability-generation capability)
                (%simulator-layout-range-generation target)
                (%simulator-ownership-capability-state capability) :ready
                (%simulator-ownership-capability-stop-token capability)
                (simulator-current-stop
                 (%simulator-address-coordinator (%simulator-layout-client layout)))
                (%simulator-layout-range-pending target) capability)
          (incf (%simulator-next-ownership layout))
          (values capability :ready nil))))))
(defun %cancel-simulator-ownership-capability (layout capability)
  (when (and (%simulator-ownership-capability-p capability)
             (eq layout (%simulator-ownership-capability-layout capability))
             (eq :ready (%simulator-ownership-capability-state capability)))
    (setf (%simulator-ownership-capability-state capability) :cancelled
          (%simulator-layout-range-pending
           (%simulator-ownership-capability-route capability)) nil))
  (values))
(defmethod update-space-ownership
    ((layout simulator-installed-layout) (capability %simulator-ownership-capability))
  (unless (and (%simulator-layout-active-p layout)
               (eq layout (%simulator-ownership-capability-layout capability))
               (eq :ready (%simulator-ownership-capability-state capability))
               (let ((coordinator
                       (%simulator-address-coordinator (%simulator-layout-client layout))))
                 (and coordinator (eq :covered (simulator-stop-state coordinator))
                      (eql (simulator-current-stop coordinator)
                           (%simulator-ownership-capability-stop-token capability))))
               (= (%simulator-ownership-capability-generation capability)
                  (%simulator-layout-range-generation
                   (%simulator-ownership-capability-route capability))))
    (host-reject :invalid-ownership-capability))
  (let ((route (%simulator-ownership-capability-route capability)))
    (setf (%simulator-layout-range-space route) (%simulator-ownership-capability-owner capability)
          (%simulator-layout-range-map route) (%simulator-ownership-capability-map capability)
          (%simulator-ownership-capability-state capability) :consumed
          (%simulator-layout-range-pending route) nil)
    (incf (%simulator-layout-range-generation route)))
  (values))

(defun %register-installed-layout-auxiliary (construction layout identity)
  ;; Installed host state is opaque to the builder; name its owned storage
  ;; explicitly. The solver solution and configuration are charged separately.
  (%register-resource-auxiliary construction identity layout)
  (let ((ranges (simulator-layout-ranges layout))
        (reserve (%simulator-ownership-reserve layout)))
    (%register-resource-auxiliary construction identity ranges)
    (%register-resource-auxiliary construction identity reserve)
    (dotimes (i (length ranges))
      (%register-resource-auxiliary construction identity (aref ranges i)))
    (dotimes (i (length reserve))
      (%register-resource-auxiliary construction identity (aref reserve i))))
  (values))
